from cli import menu
from services import *

while True:
    menu()
    pilihan = input("Pilih menu (1-6): ")

    if pilihan == "1":
        input_biodata()
        lihat_biodata()

    elif pilihan == "2":
        input_sks()
        lihat_sks()

    elif pilihan == "3":
        input_nilai()

    elif pilihan == "4":
        lihat_nilai()

    elif pilihan == "5":
        hitung_ip()

    elif pilihan == "6":
        print("Terima kasih, program selesai.")
        break

    else:
        print("Pilihan tidak valid!")