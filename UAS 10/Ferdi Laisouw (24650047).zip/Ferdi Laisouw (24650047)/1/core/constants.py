biodata = []


#Isinya Nama, Templat lahir, Tanggal lahir, Jenis kelamin dengan dictionary